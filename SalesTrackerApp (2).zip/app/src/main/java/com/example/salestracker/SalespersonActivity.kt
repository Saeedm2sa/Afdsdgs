package com.example.salestracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.salestracker.databinding.ActivitySalespersonBinding
import com.google.android.gms.location.*
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.GeoPoint
import com.google.firebase.ktx.Firebase
import java.util.*

class SalespersonActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySalespersonBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private val db = FirebaseFirestore.getInstance()
    private val user = Firebase.auth.currentUser

    companion object {
        const val LOCATION_PERMISSION_REQUEST = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalespersonBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        binding.tvWelcome.text = "سلام ${user?.email ?: "فروشنده"}"

        binding.btnStartTracking.setOnClickListener {
            checkPermissionsAndStart()
        }

        binding.btnStopTracking.setOnClickListener {
            stopLocationUpdates()
            Toast.makeText(this, "ارسال موقعیت متوقف شد", Toast.LENGTH_SHORT).show()
        }

        binding.btnLogout.setOnClickListener {
            Firebase.auth.signOut()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { location ->
                    sendLocationToFirebase(location.latitude, location.longitude)
                }
            }
        }
    }

    private fun checkPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            permissions.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }

        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (notGranted.isEmpty()) {
            startLocationUpdates()
        } else {
            ActivityCompat.requestPermissions(this, notGranted.toTypedArray(), LOCATION_PERMISSION_REQUEST)
        }
    }

    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return

        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 10000L
        ).apply {
            setMinUpdateIntervalMillis(5000L)
        }.build()

        fusedLocationClient.requestLocationUpdates(request, locationCallback, mainLooper)
        Toast.makeText(this, "ارسال موقعیت شروع شد", Toast.LENGTH_SHORT).show()
        binding.tvStatus.text = "وضعیت: در حال ارسال موقعیت"
    }

    private fun stopLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
        binding.tvStatus.text = "وضعیت: متوقف"
    }

    private fun sendLocationToFirebase(lat: Double, lng: Double) {
        val userId = user?.uid ?: return
        val email = user.email ?: "unknown"

        val data = hashMapOf(
            "userId" to userId,
            "email" to email,
            "location" to GeoPoint(lat, lng),
            "timestamp" to Date(),
            "lat" to lat,
            "lng" to lng
        )

        db.collection("locations").document(userId).set(data)

        // Also save to history collection for route tracking
        db.collection("location_history").add(
            hashMapOf(
                "userId" to userId,
                "email" to email,
                "lat" to lat,
                "lng" to lng,
                "timestamp" to Date()
            )
        )

        binding.tvStatus.text = "آخرین ارسال: $lat , $lng"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startLocationUpdates()
        } else {
            Toast.makeText(this, "دسترسی موقعیت لازم است", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopLocationUpdates()
    }
}
