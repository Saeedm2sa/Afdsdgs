package com.example.salestracker

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.salestracker.databinding.ActivityManagerMapBinding
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.ktx.Firebase
import java.text.SimpleDateFormat
import java.util.*

class ManagerMapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityManagerMapBinding
    private lateinit var mMap: GoogleMap
    private val db = FirebaseFirestore.getInstance()
    private val markers = mutableMapOf<String, Marker>()
    private var locationListener: ListenerRegistration? = null
    private val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManagerMapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        binding.btnLogout.setOnClickListener {
            Firebase.auth.signOut()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        binding.btnRefresh.setOnClickListener {
            loadAllLocations()
        }

        binding.btnShowRoutes.setOnClickListener {
            showAllRoutes()
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(35.6892, 51.3890), 10f))
        loadAllLocations()
        listenToLocationUpdates()
    }

    private fun listenToLocationUpdates() {
        locationListener = db.collection("locations")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener

                for (doc in snapshot.documents) {
                    val email = doc.getString("email") ?: continue
                    val geo = doc.getGeoPoint("location") ?: continue
                    val lat = doc.getDouble("lat") ?: geo.latitude
                    val lng = doc.getDouble("lng") ?: geo.longitude
                    val timestamp = doc.getDate("timestamp")

                    val position = LatLng(lat, lng)
                    val timeStr = timestamp?.let { dateFormat.format(it) } ?: ""

                    val existing = markers[doc.id]
                    if (existing != null) {
                        existing.position = position
                        existing.title = "$email\n$timeStr"
                    } else {
                        val marker = mMap.addMarker(
                            MarkerOptions()
                                .position(position)
                                .title(email)
                                .snippet("آخرین به‌روزرسانی: $timeStr")
                                .icon(createCustomMarker(email.firstOrNull()?.uppercaseChar() ?: 'S'))
                        )
                        marker?.let { markers[doc.id] = it }
                    }
                }
            }
    }

    private fun loadAllLocations() {
        db.collection("locations").get().addOnSuccessListener { result ->
            val bounds = LatLngBounds.Builder()
            var hasPoint = false

            for (doc in result.documents) {
                val email = doc.getString("email") ?: continue
                val geo = doc.getGeoPoint("location") ?: continue
                val lat = doc.getDouble("lat") ?: geo.latitude
                val lng = doc.getDouble("lng") ?: geo.longitude
                val timestamp = doc.getDate("timestamp")

                val position = LatLng(lat, lng)
                bounds.include(position)
                hasPoint = true

                val timeStr = timestamp?.let { dateFormat.format(it) } ?: ""

                val existing = markers[doc.id]
                if (existing != null) {
                    existing.position = position
                } else {
                    val marker = mMap.addMarker(
                        MarkerOptions()
                            .position(position)
                            .title(email)
                            .snippet("آخرین به‌روزرسانی: $timeStr")
                            .icon(createCustomMarker(email.firstOrNull()?.uppercaseChar() ?: 'S'))
                    )
                    marker?.let { markers[doc.id] = it }
                }
            }

            if (hasPoint) {
                mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), 100))
            }
        }
    }

    private fun showAllRoutes() {
        db.collection("location_history").get().addOnSuccessListener { result ->
            val userPaths = mutableMapOf<String, MutableList<LatLng>>()

            for (doc in result.documents) {
                val userId = doc.getString("userId") ?: continue
                val lat = doc.getDouble("lat") ?: continue
                val lng = doc.getDouble("lng") ?: continue

                userPaths.getOrPut(userId) { mutableListOf() }.add(LatLng(lat, lng))
            }

            val colors = listOf(Color.RED, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.BLACK, Color.CYAN)
            var colorIndex = 0

            for ((_, points) in userPaths) {
                if (points.size >= 2) {
                    points.sortBy { it.latitude }
                    val polylineOptions = PolylineOptions()
                        .addAll(points)
                        .color(colors[colorIndex % colors.size])
                        .width(5f)
                    mMap.addPolyline(polylineOptions)
                    colorIndex++
                }
            }

            Toast.makeText(this, "مسیرها روی نقشه نمایش داده شد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createCustomMarker(letter: Char): BitmapDescriptor {
        val view = LayoutInflater.from(this).inflate(R.layout.custom_marker, null)
        val tvLetter = view.findViewById<TextView>(R.id.tvMarkerLetter)
        tvLetter.text = letter.toString()
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        view.layout(0, 0, view.measuredWidth, view.measuredHeight)
        val bitmap = Bitmap.createBitmap(view.measuredWidth, view.measuredHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }

    override fun onDestroy() {
        super.onDestroy()
        locationListener?.remove()
    }
}
